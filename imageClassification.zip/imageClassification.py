# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 03:09:43 2019

@author: Nathan
"""

# Importing the Keras libraries and packages
from keras.models import Sequential
from keras.layers import Conv2D
from keras.layers import MaxPooling2D
from keras.layers import Flatten
from keras.layers import Dense
import copy
# Initialising the CNN
classifier = Sequential()
# Step 1 - Convolution
classifier.add(Conv2D(32, (3, 3), input_shape = (64, 64, 3), activation = 'relu'))
# Step 2 - Pooling
classifier.add(MaxPooling2D(pool_size = (2, 2)))
# Adding a second convolutional layer
classifier.add(Conv2D(32, (3, 3), activation = 'relu'))
classifier.add(MaxPooling2D(pool_size = (2, 2)))
# Step 3 - Flattening
classifier.add(Flatten())
# Step 4 - Full connection
classifier.add(Dense(units = 256, activation = 'relu'))
classifier.add(Dense(units = 1, activation = 'sigmoid'))
# Compiling the CNN
classifier.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])
# Part 2 - Fitting the CNN to the images
from keras.preprocessing.image import ImageDataGenerator
train_datagen = ImageDataGenerator(rescale = 1./255,
                                   shear_range = 0.2,
                                   zoom_range = 0.2,
                                   horizontal_flip = True)
test_datagen = ImageDataGenerator(rescale = 1./255)
training_set = train_datagen.flow_from_directory('training_set',
                                                 target_size = (64, 64),
                                                 batch_size = 32,
                                                 class_mode = 'binary')
test_set = test_datagen.flow_from_directory('test_set',
                                            target_size = (64, 64),
                                            batch_size = 32,
                                            class_mode = 'binary')

max_predict = 0
for n in range(10):
    print(len(training_set), "*****")
    classifier.fit_generator(training_set,
                             steps_per_epoch = 50,
                             epochs = n,
                             validation_data = test_set,
                             validation_steps = 50)
    # Part 3 - Making new predictions
    import numpy as np
    from keras.preprocessing import image
    corr = 0
    for i in range(50):
        if i%2 == 0:
            actual = 'dog'
        else:
            actual = 'cat'    
        test_image = image.load_img('catdog/catdog'+str(i)+'.jpg', target_size = (64, 64))
        test_image = image.img_to_array(test_image)
        test_image = np.expand_dims(test_image, axis = 0)
        result = classifier.predict(test_image)
        training_set.class_indices
        if result[0][0] == 1:
            prediction = 'dog'
        else:
            prediction = 'cat'
        if (prediction==actual):
            corr = corr + 1
        #print(prediction, prediction==actual)
    print("Correct: ",corr/50)
    if corr/50 > max_predict:
        max_predict = corr/50
        best_classifier = copy.deepcopy(classifier)

#128,  800,  10,  300 = .72
#128,  800,  10,  400 = .66
#128,  100,  10,  500 = .58
#128,   50,  20,   50 = 0.6
#128,   50,  30,   50 = 0.56 
#256,   50,  30,   50 = 0.66
#256,   50,  40,   50 = 0.64
    
#256,   50,  1,   50 = 0.64
#256,   50,  2,   50 = 0.5
#256,   50,  3,   50 = 0.52    
    
    
    
    
    

